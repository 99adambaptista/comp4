/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Adam Baptista

Operating system you're using (Linux, OS X, or Windows):

IDE or text editor you're using:

Hours to complete assignment:

/**********************************************************************
 *  List some information (optionally) to help me get to know you.
 **********************************************************************/

Did you take Computing I at UML?

 - If yes, who was your instructor? David Adams

 - If no, where did you transfer from?


/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/
(b) would be the next example that would most apply to this class because using unauthorized materials like going online and finding the answers and just copy/paste them onto your hw, or finding someone online to do your homework for you. Then (d) would come next because if you are working in a group and you sabotage your groups work by not doing it or messing it up on purpose. Then (e) by doing all the work in a group project. Then (c) and (f)


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
None, only sfml website


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
figuring out how to place a texture inside the circle.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
esc button closes program
space button moves sprite back to the middle
arrow keys move the ball and change the color based on the direction of movement

