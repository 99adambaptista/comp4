/**********************************************************************
 *  readme.txt template                                                   
 *  Guitar Hero: GuitarString implementation and SFML audio output 
 **********************************************************************/

Name: Adam Baptista
CS Login:


Hours to complete assignment : 5

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes, I completed the whole assignment, the only issues are that the keys "'" and ' '
dont work. I know this because they dont make sounds when they are pressed.


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 *  If you completed the AutoGuitar, what does it play?
 **********************************************************************/
I tried, but I only got different sounding guitar sounds. I did this by changing the frequency

/**********************************************************************
 *  Does your GuitarString implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
 Yes, my guitarstring implementation passed the unit tests.

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
had to use google to figure out the unicode stuff for the event.


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
My original ringbuffer.cpp did not work when i implemented the guitarstring.cpp,
and guitarhero.cpp, so I had to fix it.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/