/**********************************************************************
 *  Linear Feedback Shift Register (part A) ps1a-readme.txt template
 **********************************************************************/

Name:Adam Baptista
Hours to complete assignment:3 days, i didnt keep track how many hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
Created a linear feedback shift register that creates psudo random bits.
created step and generate functions and overloaded << operator.



/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
none



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
had to google how to boosttest

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
boosttest, never did it, took me a while to figure it out, most of the 
time spent was watching youtube on how to do boosttest.
/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
misnamed LFSR as LSFR and am too scared to change all the names as i do 
not want to break my program, will fix for ps1b.
