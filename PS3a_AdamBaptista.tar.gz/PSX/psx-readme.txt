PS3a

Changes I made to the original homework:

I fixed the cin for reading the planets because in the original homework that I had
submitted, I didn't use it correctly so that it did not read the planets properly.
Another thing that I had changed from the original was that I added the scaling, which
helped displat the planets correctly in their proper places. I also used cpplint.py to
fix the styling of my main.cpp, planets.cpp, and planets.hpp. There might be a few more
changes that I must have forgotten about because I fixed ps3a a while back, because if I
had not I would not have been able to complete ps3b.
