/**********************************************************************
 *  Linear Feedback Shift Register (part B) ps1b-readme.txt template
 **********************************************************************/

Name: Adam Baptista
OS: Linux
Machine (e.g., Dell Latitude, MacBook Pro): Dell XPS
Text editor: Vim and VSCode
Hours to complete assignment: around 3-4 hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
Encrypt an image using the LFSR generate command and save that image, then 
decrypt that image to get the original image using the same LFSR generate
command.
/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
none, only esc key to close because I got lazy



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
Asked for help with the input for the code bcause I didnt know how to do it

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Only serious problem I encountered was that I copied and pasted p.r ^ lfsr.generate(5)
for the p.g and p.b and it took me forever to find out what was wrong with it.
and the make file, I'm not good with make files, gotta study

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/